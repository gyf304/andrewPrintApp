chrome.app.runtime.onLaunched.addListener(function() {
  chrome.app.window.create('content/chrome.html', {
    'outerBounds': {
      'width': 400,
      'height': 500
    }
  });
});