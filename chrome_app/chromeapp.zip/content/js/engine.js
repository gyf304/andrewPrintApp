var engine = {};
engine.devices = {};
engine.common = {};